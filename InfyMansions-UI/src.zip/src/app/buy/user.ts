import { Capability } from '../../../node_modules/protractor';

export class User{
    wishlist:Array<string>
    name:String;
    emailId:String;
    contactNo:Number;
    City:String;
    area:String;
    pincode:Number
    password:String;
    userId:String;
}